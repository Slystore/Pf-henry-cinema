// import { v4 as uuidv4 } from "uuid";

const dataSlider = [
  {
    id: 1,
    title: "Lorem ipsum",
    subTitle: "Lorem"
  },
  {
    id: 2,
    title: "Lorem ipsum",
    subTitle: "Lorem"
  },
  {
    id: 3,
    title: "Lorem ipsum",
    subTitle: "Lorem"
  },
  {
    id: 4,
    title: "Lorem ipsum",
    subTitle: "Lorem"
  },
  {
    // id: uuidv4(),
    id: 5,
    title: "Lorem ipsum",
    subTitle: "Lorem"
  },
];

export default dataSlider;