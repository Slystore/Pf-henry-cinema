import { createTheme } from "@material-ui/core"

const theme = createTheme({
    // palette: {
    //     //background-color: rgb(255, 208, 0); usa dani

    //         info: {
    //         },
    //         error: {
    //         },
    //         disabled: {
    //         },
    //         success: {
    //         }
    //     }}
})

export default theme;